Kayla Jones
CS601
Assignment 1

This was an assignment about myself and I had a tough time writing it since I tend to be brief, but I 
think it came out fairly well. Also, I put anime in two separate pages because I'm talking about
different aspects of it on each page and I don't have many hobbies.

Run it by opening your browser.

All of the special features I added:
I used italicized block quotes on the Professional page.
I used "u" with a macron on the Professional page (3rd translation).
I used italicized block quotes on the Hometown page.
I put my sources under a details arrow on the Hometown page.
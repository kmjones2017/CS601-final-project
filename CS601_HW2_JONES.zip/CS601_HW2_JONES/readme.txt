Kayla Jones
CS601

Week 1
This was an assignment about myself and I had a tough time writing it since I tend to be brief, but I 
think it came out fairly well. Also, I put anime in two separate pages because I'm talking about
different aspects of it on each page and I don't have many hobbies.

Run it by opening your browser.

All of the special features I added:
I used italicized block quotes on the Professional page.
I used "u" with a macron on the Professional page (3rd translation).
I used italicized block quotes on the Hometown page.
I put my sources under a details arrow on the Hometown page.

Week 2
I tried my absolute best to figure out how make the navigation menu change between horizontal and
vertical based on the size of the screen, but I could not get the code to cooperate. I made it
a flexbox and attempted to get it to change to "flex-direction: column" on a smaller screen size, but
to no avail. Any insight on this would be much appreciated.

Run it by opening your browser.

What did I do to go above and beyond?
I used a CSS grid to organize the content on several pages.
I used CSS flexbox in the header.
I adjusted the content of my website to change between three screen sizes.
I made the hyperlinks in my navigation bar look like buttons.
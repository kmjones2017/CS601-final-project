Kayla Jones

# CS601 - Assignment 5

## How to run

Run it by opening your browser and opening the file or navigating to cs601-hw5-kj.glitch.me/.

## What's in this project?

This was a project to create and format a JSON file and display it in a webpage as a table. I found this pretty challenging but I eventually got to a satisfactory outcome.

## Special features:

I styled the page with CSS. I also made the button wiggle. I used loops to create the table header and rows.
